import { Component, OnInit } from '@angular/core';
import { User } from '../Model/user';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})


export class UserComponent implements OnInit {


  
userArr:User[]=[];
user:User;
  constructor( private service:ServiceService, private router:Router) {
    this.user=new User();
   }

  ngOnInit() {
  }

  addUser()
  {
    this.service.addUser(this.user).subscribe(
      data=>{
        console.log(data);
        this.router.navigate(['/adminuser']);
      }
    )
  }

}
