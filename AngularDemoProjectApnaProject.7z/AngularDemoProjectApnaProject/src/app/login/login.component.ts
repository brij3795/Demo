import { Component, OnInit } from '@angular/core';
import { Login } from '../Model/admin';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  loginArr:Login[]=[];
  login:Login;
  adminEmail:any;
  adminPassword:any;
  loginCheck:Login[]=[];
  adminCheck:Login;
  constructor(private router: Router, private service: ServiceService) {

    this.login=new Login();
   
   }

  ngOnInit() {
  }

  getAdmin(){
    this.service.getAdmin().subscribe(res=>{
     this.loginCheck=res;
     this.adminCheck=this.loginCheck[0];

     if(this.login.adminEmail===this.adminCheck.adminEmail&&
      this.login.adminPassword===this.adminCheck.adminPassword)
     {
      this.router.navigate(['/admin']);
     }
     else{
       alert('wrong');
     }
    })
  }

}
