import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

import { AdminComponent } from './admin/admin.component';
import { PatientComponent } from './patient/patient.component';
import { UserComponent } from './user/user.component';
import { AdminUserComponent } from './admin-user/admin-user.component';




const routes: Routes = [
  { path:'', redirectTo: '/login', pathMatch: 'full' },
  { path: "login", component: LoginComponent, pathMatch:'full' },
  { path: "patient", component: PatientComponent },
  { path: "admin", component: AdminComponent, pathMatch:'full' },
  { path: "user", component: UserComponent, pathMatch:'full' },
  { path: "adminuser", component: AdminUserComponent, pathMatch:'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})


export class AppRoutingModule { }
