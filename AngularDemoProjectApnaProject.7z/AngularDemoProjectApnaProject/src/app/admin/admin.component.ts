import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Patient } from '../Model/patient';
import { jsonpCallbackContext } from '@angular/common/http/src/module';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {


  patientArr:Patient[]=[];
  patient:Patient;

  aPulse:number=0;
  aMinus:number=0;
  abPulse:number=0;
  abMinus:number=0;
  bPulse:number=0;
  bMinus:number=0;
  oPulse:number=0;
  oMinus:number=0;
  count:number=0;
  constructor(private router: Router, private service: ServiceService) { }

  ngOnInit() {
    console.log(this.patientArr);
    this.service.getPatient().subscribe(res=>{
      this.patientArr=res;
    JSON.stringify(this.patientArr);
     //console.log(this.patientArr);
    return this.patientArr;
    });
  }

  notificationBloodGroup(bloodGroup:String){
    console.log(bloodGroup)
    if(bloodGroup==="A+")
    {
      
       if(this.aPulse>0)
      {
      alert('BloodGroup Match');
      this.aPulse--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }


    if(bloodGroup==="A-")
    {
      
       if(this.aMinus>0)
      {
      alert('BloodGroup Match');
      this.aMinus--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }


    if(bloodGroup==="AB+")
    {
      
       if(this.abPulse>0)
      {
      alert('BloodGroup Match');
      this.abPulse--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }


    if(bloodGroup==="AB-")
    {
      
       if(this.abMinus>0)
      {
      alert('BloodGroup Match');
      this.abMinus--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }
  

    if(bloodGroup==="O+")
    {
      
       if(this.oPulse>0)
      {
      alert('BloodGroup Match');
      this.oPulse--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }

  
    if(bloodGroup==="O-")
    {
      
       if(this.oMinus>0)
      {
      alert('BloodGroup Match');
      this.oMinus--;
      }
      else{
        alert('Blood Group Not Matched');
      }
    }
  
  }

    }