export class User{
    id:number;
    userFirstName:String; 
    userLastName:String;
    userDOB:String;
    userGender:String;
    userMobile:String;
    userEmail:String;
    userBloodGroup:String;

 }