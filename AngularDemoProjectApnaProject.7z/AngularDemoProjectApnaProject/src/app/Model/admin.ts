export class Login{
   
    adminEmail:String; 
    adminPassword:String;
   
 }
 