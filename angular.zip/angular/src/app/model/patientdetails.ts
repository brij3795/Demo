export class Patient {
  filter(arg0: (u: any) => boolean): Patient {
    throw new Error("Method not implemented.");
  }
    id: number;
    firstName: string;
    lastName: string;
    patientContact: string;
    patientBloodGroup: string;
    patientHospitalLoc: string;
    pDOB:String;
    patientEmail:String;
    patientGender:String;
    userId:number;
}
