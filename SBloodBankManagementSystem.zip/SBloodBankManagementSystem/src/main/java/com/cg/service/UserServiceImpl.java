package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.BloodBank;
import com.cg.entity.User;
import com.cg.repo.BloodBankRepo;
import com.cg.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;

	@Autowired
	BloodBankRepo bloodBankRepo;

	@Override
	public User addUser(User u) {
		/*
		 * List<BloodBank> bb = bloodBankRepo.findByBloodgroup(u.getUserBloodGroup());
		 * for (BloodBank bloodBank : bb) { int id = bloodBank.getId(); BloodBank bank =
		 * bloodBankRepo.findById(id).get(); int quantity = bank.getQuantity();
		 * quantity++; bank.setQuantity(quantity); List<User> users =
		 * bloodBank.getUser(); users.add(u);
		 * 
		 * bank.setUser(users); bloodBankRepo.save(bank); }
		 */

		return userRepo.save(u);
	}

	@Override
	public List<User> getUser() {
		return (List<User>) userRepo.findAll();
	}

	public List<User> matchUser(String bloodgroup, String location) {

		List<User> users = userRepo.findByUserBloodGroupAndUserAddress(bloodgroup, location);

		return users;

	}

	@Override
	public User selectUser(int id) {

		User user = userRepo.findById(id).get();
		userRepo.delete(user);

		/*
		 * List<BloodBank> bb =
		 * bloodBankRepo.findByBloodgroup(user.getUserBloodGroup()); for (BloodBank
		 * bloodBank : bb) { int quantity = bloodBank.getQuantity(); quantity--;
		 * bloodBank.setQuantity(quantity); bloodBank.getUser().remove(user);
		 * bloodBankRepo.save(bloodBank); userRepo.delete(user);
		 * 
		 * }
		 */

		return user;
	}

}
