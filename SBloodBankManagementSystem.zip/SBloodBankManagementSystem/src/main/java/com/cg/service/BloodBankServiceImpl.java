package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.BloodBank;
import com.cg.entity.User;
import com.cg.repo.BloodBankRepo;

@Service
public class BloodBankServiceImpl {

	@Autowired
	private BloodBankRepo bloodBankrepo;

	public List<User> matchBloodGroup(String patientBloodGroup, String patientLocation) {
		List<BloodBank> allbb = (List<BloodBank>) bloodBankrepo.findAll();

		List<User> matchedUser = new ArrayList<User>();
		for (BloodBank bloodBank : allbb) {
			List<User> usersbybb = bloodBank.getUser();
			for (User user : usersbybb) {
				if (user.getUserBloodGroup().equals(patientBloodGroup)
						& user.getUserAddress().equalsIgnoreCase(patientLocation)) {
					matchedUser.add(user);
				}

			}

		}
		return matchedUser;

	}

}
