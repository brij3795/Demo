package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

@Entity
@Table(name = "user_infos")
public class User {

	@Id
	@GeneratedValue
	private int id;

	private String userFirstName;

	private String userLastName;

	private String uDOB;

	private String userEmail;

	/*
	 * public BloodBank getUserBloodBank() { return userBloodBank; }
	 * 
	 * public void setUserBloodGroup(BloodBank userBloodGroup) { this.userBloodBank
	 * = userBloodGroup; }
	 */
	
	

	private String userContact;
	
	@Column(name = "user_blood_group")
	private String userBloodGroup;

	private String userAddress;
	
	/*
	 * @Column(name = "userId") private int userId;
	 */
	/*
	 * @ManyToOne
	 * 
	 * @JoinColumn(name = "userId", nullable = false, insertable = false, updatable
	 * = false) private BloodBank userBloodBank;
	 */
	/*
	 * public int getUserId() { return userId; }
	 * 
	 * public void setUserId(int userId) { this.userId = userId; }
	 */

	public String getUserFirstName() {
		return userFirstName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	/*
	 * public int getUserId() { return userId; }
	 * 
	 * public void setUserId(int userId) { this.userId = userId; }
	 */

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getuDOB() {
		return uDOB;
	}

	public void setuDOB(String uDOB) {
		this.uDOB = uDOB;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserContact() {
		return userContact;
	}

	public void setUserContact(String userContact) {
		this.userContact = userContact;
	}

	public String getUserBloodGroup() {
		return userBloodGroup;
	}

	public void setUserBloodGroup(String userBloodGroup) {
		this.userBloodGroup = userBloodGroup;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

}
