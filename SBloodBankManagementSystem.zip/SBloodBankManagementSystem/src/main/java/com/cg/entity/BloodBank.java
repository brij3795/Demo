package com.cg.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class BloodBank {

	@Id
	@GeneratedValue
	private int id;

	private String bloodgroup;

	private int quantity;

//	private String location;

	/*
	 * public String getLocation() { return location; }
	 * 
	 * public void setLocation(String location) { this.location = location; }
	 */

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userId")
	private List<User> users;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBloodgroup() {

		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		int i = this.getQuantity();
		setQuantity(i++);
		this.bloodgroup = bloodgroup;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public List<User> getUser() {
		return users;
	}

	public void setUser(List<User> users) {
		this.users = users;
	}

}
