package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.User;
import com.cg.repo.UserRepo;

@Service
public class UserserviceImpl implements UserService {

	
	@Autowired
	UserRepo userRepo;
	
	@Override
	public User addUser(User u) {
		return userRepo.save(u);
	}

	@Override
	public List<User> getUserList() {
		return (List<User>) userRepo.findAll();
	}

}
